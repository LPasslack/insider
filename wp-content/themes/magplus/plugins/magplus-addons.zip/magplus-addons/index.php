<?php
/**
 * Index Page
 *
 * @package magplus
 * @since 1.0
 */
get_template_part('page-templates/blog-list');

