<div class="tt-heading amp-title-wrapper title-wrapper">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="tt-heading-title"><?php echo magplus_get_the_title(); ?></h1>
      </div>
    </div>
  </div>
</div>